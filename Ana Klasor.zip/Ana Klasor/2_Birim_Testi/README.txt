Birim Testleri Çalıştırma Kılavuzu: 
Bu proje, NUnit çerçevesi kullanılarak yazılmış birim testlerini içerir. Testler, projeee.Tests namespace'inde yer alır ve projenin önemli fonksiyonlarının doğru çalıştığını doğrulamak için tasarlanmıştır.

Gereksinimler:
• Visual Studio veya uyumlu bir C# IDE'si
• NUnit ve Moq kütüphaneleri (NuGet üzerinden yüklenebilir)

Testlerin Çalıştırılması:
• Proje bağımlılıklarını yükleyin:
• Visual Studio'da NuGet Package Manager üzerinden NUnit ve Moq kütüphanelerini yükleyin.
- Install-Package NUnit
- Install-Package Moq

• Test Projesini Açın:
Test dosyasını Visual Studio'da açın.

• Test Gezgini'ni Başlatın:
Visual Studio'da Test > Test Explorer sekmesine giderek Test Gezgini'ni açın.

• Testleri Çalıştırın:
Test Gezgini'nden tüm testleri seçin ve Run All butonuna tıklayın.


