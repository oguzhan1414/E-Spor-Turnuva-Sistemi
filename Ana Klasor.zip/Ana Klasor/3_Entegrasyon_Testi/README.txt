Entegrasyon Testleri:
Gereksinimler:
• .NET Framework
• NUnit ve Moq paketleri
• Visual Studio

Testlerin Çalıştırılması:
1-) Gerekli Paketleri Yükleme: Projeye gerekli test kütüphanelerini yüklemek için NuGet paket yöneticisini kullanın:
• NUnit
• Moq

2-) Testleri Çalıştırma:
• Visual Studio'da Test Explorer penceresini açın.
• Testleri derleyin ve ardından Run All Tests seçeneği ile testleri çalıştırın.

Test Senaryoları:
• Login_ValidCredentials_ShouldRedirectToCorrectPage: Geçerli kullanıcı bilgileri ile giriş yapıldığında doğru sayfaya yönlendirilip yönlendirilmediğini test eder.

• Login_InvalidCredentials_ShouldReturnErrorMessage: Geçersiz giriş bilgileriyle giriş yapıldığında hata mesajı döndürülüp döndürülmediğini test eder.

• Register_DuplicateEmail_ShouldReturnErrorMessage: Kayıt sırasında zaten var olan bir e-posta adresi kullanıldığında hata mesajı döndürülüp döndürülmediğini test eder.

• Register_ValidData_ShouldRedirectToLogin: Geçerli verilerle kayıt yapıldığında kullanıcıyı giriş sayfasına yönlendirir.