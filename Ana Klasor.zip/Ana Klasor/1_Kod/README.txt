E-Spor Yönetim Sistemi

Gerekli Adımlar:
1. Visual Studio'yu açın ve projeyi yükleyin.
2. Projeyi derleyin ve çalıştırın.
3. Entity Framework kullanıldığı için, veritabanı bağlantısını kontrol edin ve gerekli migration işlemlerini yapın.

Giriş Yapmak:
- Uygulama çalıştıktan sonra giriş ekranı görünecektir.
- Kullanıcı adı ve şifre ile giriş yapabilirsiniz. (Varsayılan kullanıcılar veritabanında olmalıdır).

Kayıt Olmak:
- Giriş ekranında "Kayıt Ol" butonuna tıklayarak yeni bir kullanıcı kaydedebilirsiniz.
- Kayıt işlemi için geçerli bir e-posta ve şifre girmeniz gerekmektedir.

Bağlantı:
- Veritabanı bağlantısı `App.config` dosyasındaki `connectionStrings` bölümünde belirtilmiştir. Lütfen bağlantı bilgilerini doğru giriniz.
